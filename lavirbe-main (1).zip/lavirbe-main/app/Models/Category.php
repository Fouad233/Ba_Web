<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    /** @use HasFactory<\Database\Factories\CategoryFactory> */
    use HasFactory;

    protected $fillable = ['name'];

    function articles()
    {
        return $this->hasMany(Article::class, 'category_id', 'id');
    }

    function faqs()
    {
        return $this->hasMany(Faq::class, 'category_id', 'id');
    }
}
